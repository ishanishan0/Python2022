# python2022
This is my python2022 repository where all files and work for my python courses will be stored.
